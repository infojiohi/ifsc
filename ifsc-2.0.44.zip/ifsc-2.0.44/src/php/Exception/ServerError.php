<?php

namespace Razorpay\IFSC\Exception;

class ServerError extends \RuntimeException
{

}
